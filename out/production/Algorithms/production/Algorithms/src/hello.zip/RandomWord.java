
import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

public class RandomWord {
    public static void main(String[] args) {
        String s = StdIn.readString();
        int i = 1;
        while (StdIn.isEmpty()) { //输出第i个字的，1/i;
            int p = 1/i;
            boolean b = StdRandom.bernoulli(p);
            if (b) {
                i++;
                StdOut.println(s + '\n');
            }
        }
    }
}
